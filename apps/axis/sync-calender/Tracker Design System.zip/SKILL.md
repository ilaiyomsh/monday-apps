---
name: tracker-design
description: Use this skill to generate well-branded interfaces and assets for Tracker, the Hebrew-first work-hours reporting calendar that runs as a Monday.com Board View. Provides essential design guidelines, colors, type, fonts, assets, and a UI kit recreation for prototyping new screens, slides, or production-shaped mockups.
user-invocable: true
---

Read the `README.md` file within this skill, and explore the other available files (`colors_and_type.css`, `fonts/`, `assets/`, `preview/`, `ui_kits/tracker/`).

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. Reference `colors_and_type.css` (or copy its values) so the work picks up the brand instantly — Monday blue (`#0073EA`) for chrome, Google blue (`#1A73E8`) for the calendar grid, Rubik for everything, the event-type color set (vacation green, sick red, reserves blue) as semantic constants.

If working on production code in `tracker/`, copy assets and read the rules here to become an expert in designing with this brand. The component patterns in `ui_kits/tracker/` mirror real components under `tracker/src/components/` and are a faithful starting point.

If the user invokes this skill without any other guidance, ask them what they want to build or design — ask whether the surface is the calendar itself, the dashboard, settings, or a slide/deck about Tracker; ask which language (Hebrew RTL or English LTR); ask about device target (desktop iframe inside Monday, or mobile) — and then act as an expert designer who outputs HTML artifacts or production code, depending on the need.

Key guardrails to relay to anyone using this:
- Hebrew-first, sentence-case English, no marketing fluff.
- Pill-shaped toolbar controls (Today button, view selector, filter trigger).
- Flat surfaces — no gradients, no patterns, no illustrations, no photography.
- Event-type colors carry meaning across the product; do not repurpose them.
- Two icon sets used in parallel (`@vibe/icons` + `lucide-react`) — both are stroked, 1.5–2 px, rounded caps, single color via `currentColor`.
- Emoji only as inline copy markers (`⚠️`) and for holidays (`🕎`) — never in chrome.
