# Assets

Visual assets distilled from the Tracker codebase. Tracker has no real logo or marketing assets — it is a Monday Board View that lives inside the Monday workspace. The closest brand mark is the stopwatch loader.

## What's here

| File | What it is | Source |
|---|---|---|
| `stopwatch-loader.svg` | The animated stopwatch the app uses as splash + transition loader. Closest thing to a brand glyph. | `tracker/src/components/StopwatchLoader/StopwatchLoader.jsx` |
| `wordmark.svg` | Stand-in wordmark — stopwatch glyph + "Tracker" in Rubik 600. **Not a real logo.** Use only for mocks. | Composed here |

## Iconography (referenced, not bundled)

The app uses two icon libraries at runtime. They are installed as npm packages, not bundled SVG files. For mocks:

- **Lucide** — available via CDN at `https://unpkg.com/lucide@latest`. Use directly in mocks. Examples used in Tracker: `Settings`, `BarChart3`, `Trash2`, `ChevronDown`, `Filter`.
- **`@vibe/icons`** — Monday's set, no public CDN. Substitute the closest Lucide equivalent and flag the substitution. Examples used in Tracker: `NavigationChevronLeft/Right` (≈ Lucide `ChevronLeft/Right`), `DropdownChevronDown` (≈ Lucide `ChevronDown`).

## What's missing

- A real logo / wordmark.
- App icon / favicon (none in the codebase).
- Any photography, illustrations, or marketing imagery (Tracker has none).
- Local font files (Rubik is loaded from Google Fonts).

If you need any of the above for production work, ask the user.
