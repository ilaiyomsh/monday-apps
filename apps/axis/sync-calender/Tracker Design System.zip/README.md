# Tracker Design System

A design system distilled from **Tracker** — a Hebrew-first work-hours reporting app embedded in [monday.com](https://monday.com) as a Board View. Tracker is a single product: a drag-and-drop calendar (`react-big-calendar`) that lets people log billable / non-billable / routine hours and full-day events (vacation, sick, reserves) against any Monday board they configure.

It is built on Monday's **Vibe** design system (`@vibe/core`, `@vibe/icons`) with a **Google-Calendar-flavored layout** for the grid itself. RTL Hebrew is the primary direction; LTR English is a secondary locale.

## Sources

- **Codebase** (mounted, read-only): `tracker/` — React 18 + Vite 6, ~1.6kloc `MondayCalendar.jsx`, with feature components under `tracker/src/components/`.
- **Tokens**: `tracker/src/styles/tokens.css` and `tracker/src/styles/calendar/variables.css` are the source of truth for color, spacing, radius, motion. Mirrored into `colors_and_type.css` here.
- **Vibe reference**: `tracker/docs/monday-vibe-tokens-full.json` — full dump of Vibe's CSS variables.
- **Copy / tone**: `tracker/src/i18n/locales/{he,en}/translation.json` — every user-facing string in both languages.
- **Architecture / patterns**: `tracker/CLAUDE.md`, `tracker/ARCHITECTURE.md`, `tracker/README.md`.

## Index

| File | What's there |
|---|---|
| [`README.md`](./README.md) | This file — context, content + visual foundations, iconography. |
| [`colors_and_type.css`](./colors_and_type.css) | All CSS custom properties (color, type, spacing, radius, shadow, motion). |
| [`fonts/`](./fonts/) | Rubik via Google Fonts CDN (no local files yet — see "Caveats"). |
| [`assets/`](./assets/) | Logos, brand glyphs, the stopwatch loader SVG, event-type swatches. |
| [`preview/`](./preview/) | Cards rendered into the Design System tab — type, colors, components. |
| [`ui_kits/tracker/`](./ui_kits/tracker/) | High-fidelity calendar recreation with EventModal, FilterBar, Dashboard. |
| [`SKILL.md`](./SKILL.md) | Agent SKILL entry point — drop this folder into Claude Code skills. |

## Product context

**What it is**: a Monday.com **Board View** — an app rendered inside a Monday iframe, communicating with the platform via `monday-sdk-js` (postMessage / GraphQL). It is *not* a standalone web app and is *not* on a public marketing surface; users only encounter it inside their Monday workspace, with Monday's chrome around it.

**Who uses it**: employees logging hours, and managers approving them. Mostly Israeli teams (hence Hebrew-first + Hebcal holiday support). Many open it on mobile during the day, so the entire UI has a real mobile mode (single-row toolbar, bottom-sheet modals, swipe between days, 44px touch targets).

**Core flows**:
1. Drag-create or tap an empty slot → **EventModal** opens → pick project / task / classification → save.
2. Drag-create on the all-day row → **AllDayEventModal** → pick vacation / sick / reserves → save (supports bulk multi-day).
3. Filter calendar by reporter and/or project from a single combined **FilterBar** dropdown.
4. Switch to **Dashboard** for per-employee, per-project hour totals + pie/bar charts.
5. Manager toggles **selection mode** to bulk-approve / reject reports.

**Event vocabulary** (these labels show up everywhere — keep them stable):

| Hebrew | English | Color | Meaning |
|---|---|---|---|
| שעתי | Hourly | `#3174ad` blue | Default timed event with hours |
| לא לחיוב | Non-billable | depends on routine sub-type | Time spent but not billed to a project |
| שוטף | Routine | `#fdab3d` orange | Recurring internal work |
| פנימי | Internal | `#3174ad` blue | Internal project work (when distinction is on) |
| חיצוני | External | `#00ca72` green | External / client project (when distinction is on) |
| חופשה | Vacation | `#00c875` green | Full-day off |
| מחלה | Sick | `#e2445c` red | Sick day |
| מילואים | Reserves | `#579bfc` blue | Military reserves day |
| זמני | Temporary | hollow / outlined | Planned-but-not-yet-reported event |

## Content fundamentals

**Tone is utilitarian and direct.** Tracker is a work tool that lives inside another work tool — there's no marketing voice, no onboarding excitement, no "let's get started!". Strings are short, declarative, second-person where action is implied. The Hebrew is just as plain as the English; this is not a place for clever copy.

**Voice**:
- **Imperative for actions** — "שמירה" / "Save", "בחר פרויקט" / "Select project", "אשר הכל" / "Approve all". Never "Click here to save" or "Tap to select a project".
- **Implicit second person** in instructions — "יש לבחור פרויקט" ("a project must be selected" / "Project is required"). The English mirrors this with passive-voiced labels: "Project is required", not "Please pick a project".
- **No mascot, no first person**. No "we", no "I". The tool does not personify itself.
- **No marketing softeners** — no "great!", "awesome", "easy", "simple". Validation messages tell you what's wrong, not how you feel about it.

**Casing**:
- **English**: Sentence case for everything — labels, buttons, menu items, dialog titles. "Reporting settings", "Approve all", "Data mapping". No Title Case. No ALL CAPS except for two-letter status codes.
- **Hebrew**: No casing concept; uses concise, precise terminology.

**Lengths**:
- Buttons: 1–3 words ("Save", "Cancel", "Approve all", "Approve all (billable)").
- Labels: 1–2 words ("Project", "Task", "Classification", "Notes" / "פרויקט", "משימה", "סיווג", "מלל חופשי").
- Validation messages: one short sentence ("Project is required" / "יש לבחור פרויקט").
- Empty states: one short line ("No projects available" / "אין פרויקטים זמינים").

**Examples lifted directly from the product** (English):

> Reporting settings · Report structure · Data mapping · Additional settings · Calendar settings
> Time report · Original event: · Add notes here…
> Select reports for approval · Approve all · Approve all (billable)
> 1 event selected · {{count}} events selected · Clear selection
> Settings incomplete · Complete the fields in this tab
> File structure is invalid · File is not valid settings JSON
> Cannot edit a future event

**Hebrew tone signals**:
- `יש ל...` ("one must…") for required-field validation — formal but not stiff.
- `בחר X` ("choose X") for imperative selection.
- `הוסף הערות כאן...` ("add notes here…") for placeholders — three dots, lower-case verb-imperative.
- Emoji used only as **inline warning markers** in copy: `⚠️ לא ניתן לערוך אירוע עתידי`. Never decorative, never in UI chrome.

## Visual foundations

**Hierarchy** is established by **weight and color**, not by font scale. The product mostly uses three to four text sizes (14, 15, 16, sometimes 24 for modal titles); emphasis comes from `font-weight: 500/600` and from `--color-text` vs `--color-text-secondary`.

**Color**:
- Two related blues coexist on purpose. `--color-primary: #0073ea` is Monday Vibe blue — used for primary buttons, focus rings, link accents, active-state surfaces. `--gc-primary: #1a73e8` is Google Calendar blue — used for the calendar grid (today circle, current-time indicator, drag-create preview). Don't merge them; they signal "Monday chrome" vs "calendar grid" respectively.
- **Reds** also dual: `--color-danger: #e2445c` (Vibe red, destructive actions) and `--gc-time-indicator: #ea4335` (Google red, the now-line on the grid).
- **Event colors carry meaning** — vacation green, sick red, reserves blue are load-bearing and consistent between the calendar, the dashboard charts, and the legend. They are deliberately saturated against white event backgrounds and white text.
- Backgrounds: `#ffffff` for surfaces, `#f5f6f8` / `#f7f9fa` for sunken sections (toolbar background, dashboard canvas), `#f0f7ff` / `#e5f3ff` for primary-tinted info surfaces.

**Spacing**: 4-px base. Tokens jump 4 → 8 → 12 → 16 → 20 → 24 → 32. No half-steps. Dense — toolbar height ~36 px, button height 32–36 px, modal padding 20–32 px.

**Backgrounds & textures**: **None**. No gradients, no patterns, no illustrations, no photography. Surfaces are flat color. The only "texture" in the entire product is the SVG stopwatch loader and the colored event blocks themselves. This is deliberate: Tracker lives inside Monday, which is itself flat; competing texture would feel out of place.

**Animation**: Snappy and short.
- `--transition-fast: 0.15s ease-in-out`, `--transition-base: 0.2s`, `--transition-slow: 0.3s` cover ~90% of state changes.
- Modal entrance: 0.3s slide-up + fade. On mobile: full-height bottom-sheet slide-up.
- Multi-select pulse: 0.3s `cubic-bezier`-y scale 1 → 1.05 → 1.02.
- Loader: stopwatch with a slow hour hand (18 s rotation), fast minute hand (1.5 s), and a pressing crown button (1.5 s, 1 px translateY).
- Reduced-motion media query is respected — animations clamp to 0.01 ms.

**Hover & press**:
- Buttons darken via a named token (`--color-primary` → `--color-primary-hover`), never via `filter: brightness()`. Calendar events are the one exception — they use `filter: brightness(0.9)` because their colors are dynamic.
- Primary buttons in EventModal use a small `translateY(-1px)` on hover. No bounce, no shadow change.
- Press state on mobile is a brief `transform: scale(0.98)` with an 80 ms ease-out — long-press shows this before the modal opens.

**Borders & dividers**: All hairlines are `1 px solid var(--color-border)` (#e6e9ef) or `--color-divider` (#e0e0e0). Dashed borders only appear on **holidays** in the calendar (`1.5 px dashed rgba(255,255,255,0.6)`) and on **temporary/planned** events (`2 px solid {event color}` with a transparent fill — the "hollow" treatment).

**Corner radii**: Three values do most of the work.
- `4 / 6 / 8 px` — chips, inputs, segmented controls.
- `12 px` — cards, panels.
- `16 px` — modals.
- `9999 px` ("full") — pill buttons in the toolbar (the "Today" button, view-selector dropdown, filter trigger, nav arrows are circular). Pills are a signature element of the toolbar.

**Shadows**: Restrained.
- `--shadow-sm: 0 1px 3px rgba(0,0,0,0.1)` — default elevation for events and floating chrome.
- `--shadow-md: 0 4px 12px` — popovers, dropdowns.
- `--shadow-lg: 0 10px 25px` — modal overlays.
- Modal overlay uses `backdrop-filter: blur(4px)` on top of a 40% black scrim.
- Drag/drop shadow is slightly larger and softer (`0 6px 10px rgba(0,0,0,0.14)`) to communicate "lifted".

**Layout rules**:
- Toolbar is a single horizontal row, sticky-feeling at the top of the calendar. On mobile it collapses into a single tight row with icon-only buttons and a centered month label.
- Modals are fixed width on desktop (1037 px for EventModal), full-screen bottom-sheet on mobile.
- The calendar grid follows `react-big-calendar` structure but is heavily restyled to look like Google Calendar — slim time gutter (60 px / 45 px mobile), today highlighted as a filled blue circle on the date number, red horizontal "now" line across the grid.
- Cards (info panels, dashboard stat boxes) use `--radius-card` (12 px), `--shadow-sm`, and a 1 px border. They never have a colored left-edge accent stripe.

**Transparency & blur**: Sparingly.
- Modal scrim is `rgba(0,0,0,0.4)` + 4 px blur.
- Mobile "peek" label during day-swipe is `rgba(255,255,255,0.92)` + 8 px backdrop blur.
- Glassmorphism is otherwise absent.

**Imagery vibe**: There is essentially no imagery. Charts (Recharts pies + bars in the Dashboard) use the same event-color palette. Avatars come from Monday and are passed through as-is.

## Iconography

Tracker uses **two** icon sets in parallel and the boundary is deliberate.

1. **`@vibe/icons`** — Monday's official icon set. Used inside the calendar chrome and any Monday-flavored UI element (toolbar dropdown chevrons, settings cog *was* this but switched to Lucide, navigation arrows on toolbar). Stroke-based, ~16–20 px viewBox, geometric, rounded line-caps. Examples in the codebase: `NavigationChevronLeft`, `NavigationChevronRight`, `DropdownChevronDown`.
2. **`lucide-react`** — used for icons not present in Vibe (or where Vibe's metaphor doesn't fit). Same stroke style, same line-cap, slightly thinner default stroke (1.5 vs 2). Examples in the codebase: `Settings`, `BarChart3` for the Dashboard button, `Trash2` for delete, etc.

**Visual character**: Both sets share an aesthetic — **outlined / stroke-style, 1.5–2 px stroke, rounded caps and joins, simple geometric shapes, no fills, no two-tone, no color**. They render in `currentColor` so they inherit the text color of the button they sit in. **Stroke width matches**: 1.5 px in display contexts, 2 px in tight contexts.

**Sizes**:
- `--icon-xs: 12px` — inline status markers.
- `--icon-sm: 16px` — toolbar buttons, small chip icons.
- `--icon-md: 20px` — primary toolbar actions (default).
- `--icon-lg: 24px` — settings dialog, dashboard cards.

**Brand glyph**: The **stopwatch loader** (`assets/stopwatch-loader.svg`) is the closest thing to a brand mark. A 24-px SVG: stroked circle (ring), two clock hands at different speeds, and a tappable crown button on top. Both Vibe's primary blue (`--color-loader-accent: #6161ff`, intentionally violet-leaning to stand out from the UI blue) and a dark indigo (`--color-loader-dark: #181b34`) appear. Used as the splash loader when the app boots and as a 50%-opacity overlay during view transitions.

**Emoji**:
- Used in **two** specific contexts only:
  - `⚠️` as an inline copy marker in warnings ("⚠️ Cannot edit a future event").
  - `🕎` as the **only** visual marker for Jewish holidays on the calendar grid (left-anchored, 12 px, 0.9 opacity). This is product-meaningful, not decoration.
- All other UI uses Vibe or Lucide. Never emoji in buttons, menus, or labels.

**Unicode**: `✓` / `✕` (check / x) used inside the manager-mode approval checkbox on events and the mobile selection-cancel button. That's it.

## Caveats

- **No real logo.** Tracker is a Monday Board View — it has no marketing logo, no app icon, no product wordmark. The closest brand asset is the stopwatch loader. If a logo is needed for a slide/mock, ask the user; do not invent one.
- **No bundled font files.** The codebase loads Rubik from Google Fonts via `<link>` (see `tracker/index.html`). `fonts/` here is a placeholder — if you need offline TTFs, ask the user.
- **No screenshots / no Figma access** were provided in this run. The UI kit recreations are sourced directly from CSS modules + JSX in `tracker/src/components/`, which is more authoritative than screenshots but means I haven't visually confirmed pixel-for-pixel parity for every component state.
- **Icons aren't bundled** as files — both `@vibe/icons` and `lucide-react` are npm packages, and the design system here references them by name. For mocks, Lucide is available on CDN; Vibe is not, so substitute Lucide where parity is needed and flag it.
