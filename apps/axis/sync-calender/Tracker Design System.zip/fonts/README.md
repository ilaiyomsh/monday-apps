# Fonts

Tracker uses **Rubik** for all UI text (Latin + Hebrew), and the platform monospace stack for code.

## Loading

The codebase loads Rubik from Google Fonts via a `<link>` tag in `tracker/index.html`:

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Rubik:ital,wght@0,300..900;1,300..900&display=swap" rel="stylesheet">
```

This pulls the full variable font — weights 300–900, regular + italic, with Hebrew, Latin, and Cyrillic subsets.

## Stack

```css
--font-family: 'Rubik', 'Helvetica Neue', Arial, sans-serif;
--font-family-mono: source-code-pro, Menlo, Monaco, Consolas, 'Courier New', monospace;
```

## Caveat

No local TTF/WOFF2 files are bundled here — the codebase relies on Google Fonts. If you need offline assets for a print export or a deck, drop them into this folder and add an `@font-face` block to `colors_and_type.css`.
