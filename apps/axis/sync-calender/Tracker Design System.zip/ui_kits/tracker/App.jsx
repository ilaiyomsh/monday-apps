// App — top-level state, view switching, modal handling.

const SEED_EVENTS = [
  { id: 'e1', dayIdx: 0, start: '09:00', end: '10:30', title: 'Acme — site redesign', color: '#3174ad', project: 'Acme — Site redesign', stage: 'Design' },
  { id: 'e2', dayIdx: 0, start: '11:00', end: '12:00', title: 'Standup', color: '#3174ad', project: 'Internal', stage: 'Routine' },
  { id: 'e3', dayIdx: 1, start: '09:30', end: '11:00', title: 'Client workshop', color: '#00ca72', project: 'Globex — Discovery', stage: 'Research' },
  { id: 'e4', dayIdx: 1, start: '13:00', end: '14:00', title: 'Email + admin', color: '#fdab3d', project: 'Routine', stage: '' },
  { id: 'e5', dayIdx: 2, start: '10:00', end: '12:30', title: 'Acme — site redesign', color: '#3174ad', project: 'Acme — Site redesign', stage: 'Development' },
  { id: 'e6', dayIdx: 2, start: '14:00', end: '15:00', title: 'Planned slot', color: '#0073ea', temporary: true, project: '', stage: '' },
  { id: 'e7', dayIdx: 3, start: '09:00', end: '11:00', title: 'Acme — site redesign', color: '#3174ad', project: 'Acme — Site redesign', stage: 'Design' },
  { id: 'e8', dayIdx: 3, start: '13:30', end: '15:00', title: 'Globex — workshop', color: '#00ca72', project: 'Globex — Discovery', stage: 'Research' },
  { id: 'e9', dayIdx: 4, start: '09:00', end: '10:00', title: 'Standup', color: '#3174ad', project: 'Internal', stage: 'Routine' },
  { id: 'e10', dayIdx: 4, start: '10:30', end: '13:00', title: 'Acme — site redesign', color: '#3174ad', project: 'Acme — Site redesign', stage: 'Development' },
  { id: 'e11', dayIdx: 4, start: '14:00', end: '16:30', title: 'Initech — onboarding', color: '#00ca72', project: 'Initech — Onboarding', stage: 'Design' },
];

const SEED_ALLDAY = [
  { id: 'a1', dayIdx: 1, title: 'Reserves', color: '#579bfc' },
  { id: 'a2', dayIdx: 3, title: 'Pesach', color: '#a25ddc', holiday: true },
];

const PROJECTS = ['Acme — Site redesign', 'Globex — Discovery', 'Initech — Onboarding', 'Soylent — Mobile', 'Cyberdyne — Platform', 'Hooli — Branding'];
const REPORTERS = ['Maya Cohen', 'Yossi Bar', 'Tal Ramos', 'Noa Levin', 'Itay Stern'];

function App() {
  const [isRtl, setIsRtl] = React.useState(false);
  const [view, setView] = React.useState('work_week');
  const [isDashboard, setIsDashboard] = React.useState(false);
  const [filterOpen, setFilterOpen] = React.useState(false);
  const [selectedReporters, setSelectedReporters] = React.useState([]);
  const [selectedProjects, setSelectedProjects] = React.useState([]);
  const [events, setEvents] = React.useState(SEED_EVENTS);
  const [editingEvent, setEditingEvent] = React.useState(null);
  const [modalOpen, setModalOpen] = React.useState(false);
  const [toast, setToast] = React.useState(null);
  const [viewChanging, setViewChanging] = React.useState(false);

  React.useEffect(() => {
    document.documentElement.dir = isRtl ? 'rtl' : 'ltr';
    document.documentElement.lang = isRtl ? 'he' : 'en';
  }, [isRtl]);

  function showToast(msg) {
    setToast(msg);
    setTimeout(() => setToast(null), 2400);
  }

  function handleSlotClick(dayIdx, hour) {
    const start = `${String(hour).padStart(2, '0')}:00`;
    const end = `${String(hour + 1).padStart(2, '0')}:00`;
    setEditingEvent({ dayIdx, start, end, color: '#3174ad', project: '', stage: '', notes: '' });
    setModalOpen(true);
  }

  function handleEventClick(ev) {
    setEditingEvent(ev);
    setModalOpen(true);
  }

  function handleSave(payload) {
    if (editingEvent?.id) {
      setEvents(events.map(e => e.id === editingEvent.id ? { ...e, ...payload, title: payload.project || payload.routineType || e.title } : e));
      showToast(isRtl ? 'הדיווח עודכן' : 'Report updated');
    } else {
      const id = 'e' + (events.length + 100);
      setEvents([...events, { id, ...editingEvent, ...payload, title: payload.project || 'New event' }]);
      showToast(isRtl ? 'הדיווח נשמר בהצלחה' : 'Report saved');
    }
    setModalOpen(false);
    setEditingEvent(null);
  }

  function handleDelete() {
    if (editingEvent?.id) {
      setEvents(events.filter(e => e.id !== editingEvent.id));
      showToast(isRtl ? 'הדיווח נמחק' : 'Report deleted');
    }
    setModalOpen(false);
    setEditingEvent(null);
  }

  function handleView(v) {
    setViewChanging(true);
    setView(v);
    setTimeout(() => setViewChanging(false), 300);
  }

  function toggleReporter(r) {
    setSelectedReporters(prev => prev.includes(r) ? prev.filter(x => x !== r) : [...prev, r]);
  }
  function toggleProject(p) {
    setSelectedProjects(prev => prev.includes(p) ? prev.filter(x => x !== p) : [...prev, p]);
  }
  function clearFilters() {
    setSelectedReporters([]); setSelectedProjects([]);
  }

  const filterCount = selectedReporters.length + selectedProjects.length;
  const label = isRtl ? '11 – 17 במאי 2026' : 'May 11 – 17, 2026';

  if (isDashboard) {
    return (
      <div className="app">
        <Dashboard isRtl={isRtl} onBack={() => setIsDashboard(false)} />
        {toast ? <div className="toast success">{toast}</div> : null}
      </div>
    );
  }

  return (
    <div className="app">
      <div style={{position: 'relative'}}>
        <Toolbar
          label={label}
          view={view}
          isRtl={isRtl}
          onToday={() => showToast(isRtl ? 'חזרה להיום' : 'Jumped to today')}
          onPrev={() => showToast(isRtl ? 'שבוע קודם' : 'Previous week')}
          onNext={() => showToast(isRtl ? 'שבוע הבא' : 'Next week')}
          onView={handleView}
          onToggleDir={() => setIsRtl(!isRtl)}
          onOpenFilter={() => setFilterOpen(!filterOpen)}
          filterCount={filterCount}
          filterOpen={filterOpen}
          onOpenDashboard={() => setIsDashboard(true)}
          hasIncompleteSettings={false}
        />
        {filterOpen ? (
          <FilterBar
            isRtl={isRtl}
            reporters={REPORTERS}
            projects={PROJECTS}
            selectedReporters={selectedReporters}
            selectedProjects={selectedProjects}
            onToggleReporter={toggleReporter}
            onToggleProject={toggleProject}
            onClear={clearFilters}
            onClose={() => setFilterOpen(false)}
          />
        ) : null}
      </div>

      <div style={{flex: 1, position: 'relative', overflow: 'hidden'}}>
        <CalendarGrid
          events={events}
          allDayEvents={SEED_ALLDAY}
          onEventClick={handleEventClick}
          onSlotClick={handleSlotClick}
          todayIdx={4}
          isRtl={isRtl}
        />
        {viewChanging ? (
          <div className="view-overlay"><Stopwatch size={48}/></div>
        ) : null}
      </div>

      <EventModal
        isOpen={modalOpen}
        isRtl={isRtl}
        eventData={editingEvent}
        onClose={() => { setModalOpen(false); setEditingEvent(null); }}
        onSave={handleSave}
        onDelete={handleDelete}
        projects={PROJECTS}
      />

      {toast ? <div className="toast success">✓ {toast}</div> : null}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
