// CalendarGrid — Google-Calendar-flavored week view.
// Days = Sun–Thu (Israeli work week). Hours = 9–17.
// Events are positioned absolutely against each day column.

const HOURS = [9, 10, 11, 12, 13, 14, 15, 16, 17];
const DAYS_EN = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu'];
const DAYS_HE = ['ראשון', 'שני', 'שלישי', 'רביעי', 'חמישי'];
const SLOT_HEIGHT = 60;

function timeToY(timeStr) {
  const [h, m] = timeStr.split(':').map(Number);
  return (h - HOURS[0]) * SLOT_HEIGHT + (m / 60) * SLOT_HEIGHT;
}

function durationToHeight(start, end) {
  return timeToY(end) - timeToY(start);
}

function EventBlock({ ev, onClick }) {
  const top = timeToY(ev.start);
  const height = durationToHeight(ev.start, ev.end);
  const short = height < 40;
  const classes = ['event'];
  if (short) classes.push('short');
  if (ev.temporary) classes.push('temporary');
  return (
    <div
      className={classes.join(' ')}
      style={{ top, height, '--c': ev.color }}
      onClick={e => { e.stopPropagation(); onClick(ev); }}
    >
      <div className="t">{ev.start}–{ev.end}</div>
      <div className="ttl">{ev.title}</div>
    </div>
  );
}

function CalendarGrid({ events, allDayEvents, onEventClick, onSlotClick, todayIdx, isRtl }) {
  const days = isRtl ? DAYS_HE : DAYS_EN;
  const dayNums = [10, 11, 12, 13, 14];
  // In RTL the day order naturally flips visually because the grid auto-flows;
  // we keep arrays in source order and let CSS handle it.
  return (
    <div className="cal">
      <div className="cal-head">
        <div className="cell"></div>
        {days.map((d, i) => (
          <div key={d} className={`cell ${i === todayIdx ? 'today' : ''}`}>
            {d}
            <span className={`day-num ${i === todayIdx ? 'today' : ''}`}>{dayNums[i]}</span>
          </div>
        ))}
      </div>

      <div className="allday-row">
        <div className="lbl-cell">{isRtl ? 'יומי' : 'All-day'}</div>
        {days.map((_, i) => (
          <div key={i} className="allday-cell">
            {allDayEvents.filter(e => e.dayIdx === i).map(e => (
              <div
                key={e.id}
                className={`event allday-pill ${e.holiday ? 'holiday' : ''}`}
                style={{ background: e.color }}
                onClick={ev => { ev.stopPropagation(); onEventClick(e); }}
              >
                {e.title}
              </div>
            ))}
          </div>
        ))}
      </div>

      <div className="cal-body">
        <div className="gutter">
          {HOURS.map(h => <div key={h} className="slot">{h > 12 ? `${h-12} PM` : (h === 12 ? '12 PM' : `${h} AM`)}</div>)}
        </div>
        {days.map((_, i) => (
          <div key={i} className={`day-col ${i === todayIdx ? 'today-col' : ''}`}>
            {HOURS.map((h, j) => (
              <div key={j} className="slot" onClick={() => onSlotClick(i, h)}></div>
            ))}
            {events.filter(e => e.dayIdx === i).map(e => (
              <EventBlock key={e.id} ev={e} onClick={onEventClick} />
            ))}
          </div>
        ))}
        <NowLine isRtl={isRtl} />
      </div>
    </div>
  );
}

function NowLine({ isRtl }) {
  // Pretend "now" is 11:30 on today (Thu)
  // The line spans the full grid; visual day-column offset is implied by today highlighting.
  const top = timeToY('11:30');
  return <div className="now-line" style={{ top }} />;
}

Object.assign(window, { CalendarGrid, HOURS, SLOT_HEIGHT });
