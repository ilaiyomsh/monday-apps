// EventModal — the time-report dialog.
function EventModal({ isOpen, isRtl, eventData, onClose, onSave, onDelete, projects }) {
  const [mode, setMode] = React.useState('projects'); // 'projects' | 'routine'
  const [selectedProject, setSelectedProject] = React.useState(eventData?.project || projects[0]);
  const [task, setTask] = React.useState(eventData?.task || '');
  const [classification, setClassification] = React.useState(eventData?.stage || '');
  const [notes, setNotes] = React.useState(eventData?.notes || '');
  const [errors, setErrors] = React.useState({});

  React.useEffect(() => {
    if (isOpen && eventData) {
      setSelectedProject(eventData.project || projects[0]);
      setTask(eventData.task || '');
      setClassification(eventData.stage || '');
      setNotes(eventData.notes || '');
      setErrors({});
    }
  }, [isOpen, eventData]);

  if (!isOpen) return null;

  const t = isRtl
    ? { title: 'דיווח שעות', proj: 'פרויקטים', routine: 'שוטף', project: 'פרויקט', task: 'משימה', stage: 'סיווג', notes: 'מלל חופשי', cancel: 'ביטול', save: 'שמור', del: 'מחק', search: 'חיפוש פרויקט...', taskPh: 'בחר משימה...', notesPh: 'הוסף הערות כאן...', stagePh: 'בחר סיווג', stageReq: 'יש לבחור סיווג' }
    : { title: 'Time report', proj: 'Projects', routine: 'Routine', project: 'Project', task: 'Task', stage: 'Classification', notes: 'Notes', cancel: 'Cancel', save: 'Save', del: 'Delete', search: 'Search project…', taskPh: 'Select task…', notesPh: 'Add notes here…', stagePh: 'Select classification', stageReq: 'Classification is required' };

  const dateLabel = eventData?.date || (isRtl ? 'יום חמישי, 14 במאי 2026' : 'Thu, May 14, 2026');
  const timeLabel = eventData ? `${eventData.start} – ${eventData.end}` : '';

  function handleSave() {
    const newErrors = {};
    if (mode === 'projects' && !selectedProject) newErrors.project = isRtl ? 'יש לבחור פרויקט' : 'Project is required';
    if (mode === 'projects' && !classification) newErrors.stage = t.stageReq;
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }
    onSave({ project: selectedProject, task, stage: classification, notes, mode });
  }

  return (
    <div className="modal-overlay" onClick={e => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal">
        <div className="modal-head">
          <div>
            <h2 className="modal-title">{t.title}</h2>
            <div className="modal-subtitle">{dateLabel}{timeLabel ? ` · ${timeLabel}` : ''}</div>
          </div>
          <button className="modal-close" onClick={onClose} aria-label="Close">×</button>
        </div>

        <div className="modal-body">
          <div className="mode-selector">
            <button className={`mode-btn ${mode === 'projects' ? 'active' : ''}`} onClick={() => setMode('projects')}>{t.proj}</button>
            <button className={`mode-btn ${mode === 'routine' ? 'active' : ''}`} onClick={() => setMode('routine')}>{t.routine}</button>
          </div>

          {mode === 'projects' ? (
            <>
              <div className="field">
                <div className="field-label"><span className="req">*</span>{t.project}</div>
                <input className="input" placeholder={t.search} value={selectedProject} onChange={e => setSelectedProject(e.target.value)} />
                <div className="project-grid" style={{marginTop: 10}}>
                  {projects.map(p => (
                    <button
                      key={p}
                      className={`proj-btn ${selectedProject === p ? 'selected' : ''}`}
                      onClick={() => setSelectedProject(p)}
                    >
                      {p}
                    </button>
                  ))}
                </div>
              </div>
              <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap: 16}}>
                <div className="field">
                  <div className="field-label">{t.task}</div>
                  <input className="input" placeholder={t.taskPh} value={task} onChange={e => setTask(e.target.value)} />
                </div>
                <div className="field">
                  <div className="field-label"><span className="req">*</span>{t.stage}</div>
                  <select
                    className="input"
                    value={classification}
                    onChange={e => setClassification(e.target.value)}
                    style={errors.stage ? {borderColor:'var(--color-danger)', background:'var(--color-danger-bg)'} : {}}
                  >
                    <option value="">{t.stagePh}</option>
                    <option>{isRtl ? 'פיתוח' : 'Development'}</option>
                    <option>{isRtl ? 'עיצוב' : 'Design'}</option>
                    <option>{isRtl ? 'מחקר' : 'Research'}</option>
                  </select>
                  {errors.stage ? <div style={{fontSize: '0.8rem', color: 'var(--color-danger)', fontWeight: 500}}>{errors.stage}</div> : null}
                </div>
              </div>
            </>
          ) : (
            <div className="field">
              <div className="field-label"><span className="req">*</span>{isRtl ? 'סוג דיווח שוטף' : 'Routine type'}</div>
              <select className="input">
                <option>{isRtl ? 'אדמיניסטרציה' : 'Administration'}</option>
                <option>{isRtl ? 'ישיבת צוות' : 'Team meeting'}</option>
                <option>{isRtl ? 'הדרכות' : 'Training'}</option>
              </select>
            </div>
          )}

          <div className="field">
            <div className="field-label">{t.notes}</div>
            <textarea className="textarea" placeholder={t.notesPh} value={notes} onChange={e => setNotes(e.target.value)} />
          </div>
        </div>

        <div className="modal-foot">
          {eventData?.id ? <button className="btn btn-danger" onClick={onDelete}>{t.del}</button> : null}
          <button className="btn btn-secondary" onClick={onClose}>{t.cancel}</button>
          <button className="btn btn-primary" onClick={handleSave}>{t.save}</button>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { EventModal });
