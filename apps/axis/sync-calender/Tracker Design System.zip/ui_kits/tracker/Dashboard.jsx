// Dashboard — recharts-style cards with stats + bar/legend chart.
function Dashboard({ isRtl, onBack }) {
  const t = isRtl
    ? { back: '→ חזרה ליומן', title: 'דשבורד דיווחי שעות', total: 'סך שעות', billable: 'לחיוב', nonBill: 'לא לחיוב', off: 'ימי היעדרות', byEmp: 'פילוח לפי עובד', byType: 'פילוח לפי סוג' }
    : { back: '← Back to calendar', title: 'Time reporting dashboard', total: 'Total hours', billable: 'Billable', nonBill: 'Non-billable', off: 'Off-days', byEmp: 'Hours by employee', byType: 'Hours by type' };

  const employees = [
    { name: 'Maya Cohen', hours: 38.5, max: 40 },
    { name: 'Yossi Bar', hours: 32.0, max: 40 },
    { name: 'Tal Ramos', hours: 36.5, max: 40 },
    { name: 'Noa Levin', hours: 24.0, max: 40 },
    { name: 'Itay Stern', hours: 40.0, max: 40 },
  ];

  const typeBreakdown = [
    { label: isRtl ? 'שעתי' : 'Hourly', color: '#3174ad', pct: 62 },
    { label: isRtl ? 'שוטף' : 'Routine', color: '#fdab3d', pct: 18 },
    { label: isRtl ? 'חופשה' : 'Vacation', color: '#00c875', pct: 8 },
    { label: isRtl ? 'מחלה' : 'Sick', color: '#e2445c', pct: 4 },
    { label: isRtl ? 'מילואים' : 'Reserves', color: '#579bfc', pct: 8 },
  ];

  return (
    <div style={{display:'flex', flexDirection:'column', height:'100%'}}>
      <div className="toolbar">
        <div className="tb-section">
          <button
            className="filter-trigger"
            onClick={onBack}
          >
            <span>{t.back}</span>
          </button>
          <h2 style={{margin: 0, marginInlineStart: 12, fontSize: 20, fontWeight: 700, color: 'var(--fg)'}}>{t.title}</h2>
        </div>
        <div style={{flex: 1}}/>
        <div className="tb-section tb-actions">
          <button className="icon-btn"><SettingsIcon/></button>
        </div>
      </div>

      <div className="dash">
        <div className="dash-grid">
          <div className="stat"><div className="lbl">{t.total}</div><div className="val">171.0h</div><div className="delta">+4.5h vs last week</div></div>
          <div className="stat"><div className="lbl">{t.billable}</div><div className="val">112.5h</div><div className="delta">66% of total</div></div>
          <div className="stat"><div className="lbl">{t.nonBill}</div><div className="val">42.0h</div><div className="delta neg">−2.0h vs last week</div></div>
          <div className="stat"><div className="lbl">{t.off}</div><div className="val">2d</div><div className="delta">1 sick · 1 reserves</div></div>
        </div>

        <div style={{display:'grid', gridTemplateColumns:'1.4fr 1fr', gap: 16}}>
          <div className="chart-card">
            <h3>{t.byEmp}</h3>
            <div className="bar-chart">
              {employees.map(e => (
                <div key={e.name} className="bar-row">
                  <span className="name">{e.name}</span>
                  <div className="bar-track"><div className="bar-fill" style={{width: `${(e.hours/e.max)*100}%`}}/></div>
                  <span className="num">{e.hours.toFixed(1)}h</span>
                </div>
              ))}
            </div>
          </div>
          <div className="chart-card">
            <h3>{t.byType}</h3>
            <DonutChart segments={typeBreakdown} />
            <div className="legend" style={{marginTop: 12}}>
              {typeBreakdown.map(t => (
                <div key={t.label} className="item">
                  <span className="dot" style={{background: t.color}}/>
                  <span>{t.label} · {t.pct}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function DonutChart({ segments }) {
  // Conic-gradient donut. Sum to 100 assumed.
  let acc = 0;
  const stops = segments.map(s => {
    const start = acc; acc += s.pct;
    return `${s.color} ${start}% ${acc}%`;
  }).join(', ');
  return (
    <div style={{width: 180, height: 180, margin: '0 auto', position: 'relative'}}>
      <div style={{
        width: '100%', height: '100%', borderRadius: '50%',
        background: `conic-gradient(${stops})`,
      }}/>
      <div style={{
        position:'absolute', top:'50%', left:'50%', transform:'translate(-50%,-50%)',
        width: 110, height: 110, borderRadius: '50%', background:'var(--bg)',
        display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center',
      }}>
        <div style={{fontSize: 24, fontWeight: 700, color:'var(--fg)'}}>171h</div>
        <div style={{fontSize: 11, color:'var(--fg-muted)'}}>this week</div>
      </div>
    </div>
  );
}

Object.assign(window, { Dashboard });
