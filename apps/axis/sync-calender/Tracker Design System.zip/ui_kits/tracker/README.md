# Tracker — Monday board view UI kit

A hi-fi recreation of Tracker — the work-hours reporting calendar that runs as a Monday.com Board View. Built from the actual codebase (`tracker/src/`), not from screenshots.

## What's mocked

- **Toolbar** — pill-shaped Today button, circular nav arrows, view selector, filter trigger with active count badge, Dashboard button, Settings button (with optional incomplete-settings dot).
- **FilterBar** — split-column "People" + "Projects" dropdown with per-column search and "Clear selection".
- **Calendar grid** — Google-Calendar flavor: slim time gutter, today as a filled blue date circle, red "now" line at the current minute, 60-px hour slots, Sun–Thu (Israeli work week).
- **Event blocks** — colored pills with white border + soft shadow. Short events collapse to a single row. Temporary/planned events use the hollow-outline treatment. All-day events render as `23 px` chips on a dedicated row with a holiday variant (dashed border + 🕎).
- **EventModal** — mode segmented control (Projects / Routine), project grid with selection state, task + classification fields with inline validation, free-text notes, delete affordance pinned to the start of the footer.
- **Dashboard** — stat cards, bar chart for "Hours by employee", donut chart with color legend for "Hours by type".
- **Selection action bar** (floating dark pill, available as a card in `preview/`).
- **Toast** — top-anchored success toast that auto-dismisses.
- **Stopwatch loader** — used as a transient view-change overlay when switching views.
- **RTL / LTR toggle** — flip between Hebrew (primary) and English (secondary). Strings come from the same source as `tracker/src/i18n/locales/`.

## How to interact

- Click an empty time slot → new EventModal.
- Click an event → edit it in EventModal.
- Click "Filter" → open the People/Projects dropdown; ticking items lights up the trigger and shows a count badge.
- Click the Dashboard button (graph icon) → switch to the dashboard surface.
- Click the **EN / עב** button → flip language + direction.
- Click the view selector pill → cycle Work week → Week → Day.

## Cut corners

- No drag-and-drop or resize — events are static. The real product uses `react-big-calendar` with a `dragAndDrop` HOC; we don't bring in the library.
- No real Monday GraphQL — projects/reporters are seeded constants.
- Holidays are hard-coded; the real app uses `@hebcal/core`.
- No charts library — the donut is a CSS conic-gradient, the bar chart is plain divs.
- No mobile bottom-sheet treatment in this kit (the underlying CSS supports it; the React app forces desktop layout).
- No SettingsDialog, no SettingsWizard, no UndoBanner, no ApprovalActionBar — they exist in the codebase and would slot in cleanly but are out of scope for the kit's surface area.

## Files

| File | Role |
|---|---|
| `index.html` | Loads React + Babel and the JSX files. |
| `styles.css` | All styling, lifted from `tracker/src/styles/`. |
| `icons.jsx` | Inline-SVG icons mirroring `@vibe/icons` + `lucide-react` shapes. |
| `Toolbar.jsx` | Top toolbar component. |
| `FilterBar.jsx` | People + Projects filter dropdown. |
| `CalendarGrid.jsx` | Day headers, all-day row, time gutter, event blocks, now-line. |
| `EventModal.jsx` | The time-report dialog. |
| `Dashboard.jsx` | Dashboard surface with stats + charts. |
| `App.jsx` | App root, view switching, modal handling, toast queue. |
