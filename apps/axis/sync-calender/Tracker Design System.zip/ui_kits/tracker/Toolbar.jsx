// Toolbar — the calendar's top bar. Pill-shaped controls.
function Toolbar({ label, view, onPrev, onNext, onToday, onView, isRtl, onToggleDir, onOpenFilter, filterCount, filterOpen, onOpenDashboard, isDashboard, hasIncompleteSettings }) {
  const Prev = isRtl ? ChevronRight : ChevronLeft;
  const Next = isRtl ? ChevronLeft : ChevronRight;
  const viewLabels = { day: isRtl ? 'יום' : 'Day', week: isRtl ? 'שבוע' : 'Week', work_week: isRtl ? 'שבוע עבודה' : 'Work week', month: isRtl ? 'חודש' : 'Month' };
  return (
    <div className="toolbar">
      <div className="tb-section tb-nav">
        <button className="today-btn" onClick={onToday}>{isRtl ? 'היום' : 'Today'}</button>
        <div className="nav-arrows">
          <button className="nav-btn" onClick={onPrev} aria-label="Previous"><Prev/></button>
          <button className="nav-btn" onClick={onNext} aria-label="Next"><Next/></button>
        </div>
        <span className="tb-label">{label}</span>
      </div>

      <div className="tb-section tb-filters" style={{position:'relative'}}>
        <button
          className={`filter-trigger ${filterCount > 0 ? 'active' : ''} ${filterOpen ? 'open' : ''}`}
          onClick={onOpenFilter}
        >
          <FilterIcon/>
          <span>{isRtl ? 'סינון' : 'Filter'}</span>
          {filterCount > 0 ? <span className="badge">{filterCount}</span> : null}
          <span className="chev"><ChevronDown size={14}/></span>
        </button>
      </div>

      <div className="tb-section tb-actions">
        <button className={`dash-btn ${isDashboard ? 'active' : ''}`} onClick={onOpenDashboard} aria-label="Dashboard"><BarChartIcon/></button>
        <button className="view-select" onClick={() => onView(view === 'work_week' ? 'week' : view === 'week' ? 'day' : 'work_week')}>
          <span>{viewLabels[view]}</span>
          <ChevronDown/>
        </button>
        <button className="icon-btn" onClick={onToggleDir} title="Toggle Hebrew / English">
          <span style={{fontSize: 12, fontWeight: 600}}>{isRtl ? 'עב' : 'EN'}</span>
        </button>
        <button className={`icon-btn ${hasIncompleteSettings ? 'danger-dot' : ''}`} aria-label="Settings"><SettingsIcon/></button>
      </div>
    </div>
  );
}

Object.assign(window, { Toolbar });
