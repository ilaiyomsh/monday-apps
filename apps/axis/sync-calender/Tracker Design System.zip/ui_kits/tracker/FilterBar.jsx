// FilterBar dropdown — split list of People + Projects.
function FilterBar({ isRtl, onClose, reporters, projects, selectedReporters, selectedProjects, onToggleReporter, onToggleProject, onClear }) {
  const [searchR, setSearchR] = React.useState('');
  const [searchP, setSearchP] = React.useState('');
  const filteredR = reporters.filter(r => r.toLowerCase().includes(searchR.toLowerCase()));
  const filteredP = projects.filter(p => p.toLowerCase().includes(searchP.toLowerCase()));
  return (
    <div className="filter-dropdown">
      <div className="filter-col">
        <h4>{isRtl ? 'אנשים' : 'People'}</h4>
        <input className="search" placeholder={isRtl ? 'חיפוש...' : 'Search…'} value={searchR} onChange={e => setSearchR(e.target.value)} />
        <div className="filter-list">
          {filteredR.length === 0 ? <div style={{padding:'8px', fontSize:13, color:'var(--fg-muted)'}}>{isRtl ? 'לא נמצאו תוצאות' : 'No results'}</div> : filteredR.map(r => (
            <label key={r} className="filter-item">
              <input type="checkbox" checked={selectedReporters.includes(r)} onChange={() => onToggleReporter(r)} />
              <span>{r}</span>
            </label>
          ))}
        </div>
      </div>
      <div className="filter-col">
        <h4>{isRtl ? 'פרויקטים' : 'Projects'}</h4>
        <input className="search" placeholder={isRtl ? 'חיפוש...' : 'Search…'} value={searchP} onChange={e => setSearchP(e.target.value)} />
        <div className="filter-list">
          {filteredP.length === 0 ? <div style={{padding:'8px', fontSize:13, color:'var(--fg-muted)'}}>{isRtl ? 'לא נמצאו תוצאות' : 'No results'}</div> : filteredP.map(p => (
            <label key={p} className="filter-item">
              <input type="checkbox" checked={selectedProjects.includes(p)} onChange={() => onToggleProject(p)} />
              <span>{p}</span>
            </label>
          ))}
        </div>
        <button
          onClick={onClear}
          style={{marginTop: 8, background:'none', border:'none', color:'var(--color-primary)', fontSize: 13, cursor:'pointer', fontFamily:'inherit', padding:'4px 0', textAlign:'start'}}
        >
          {isRtl ? 'נקה בחירה' : 'Clear selection'}
        </button>
      </div>
    </div>
  );
}

Object.assign(window, { FilterBar });
