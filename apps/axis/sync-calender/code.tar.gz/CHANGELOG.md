# Changelog - sync-calender

*Auto-generated. Source: `~/.change-tracker/changes.db`*

## 2026-06

### 🐛  Bugfix

- **2026-06-02** — Scheduler now flips config status to `<provider>_disconnected` + sets `lastError` on token-refresh failure, notifies the affected user and the instance owner, deep-links notifications to the Custom Object, and surfaces the disconnect pill in the UI (branch `fix/scheduler-disconnect-notify`, commits `d34b537` · `c345330` · `fc1da5c` · `3becdd2`) — **open, pending live verification 2026-06-04**
  - _Why:_ Axiom investigation found a Microsoft config (cfg=0ff12f78) stuck on `active` for 6 days despite a dead refresh token. The renewal cron was the only path hitting the dead token (the push subscription had already expired, so no webhooks fired), but its catch block only logged — it never updated status or notified anyone. The admin UI consequently showed the user as "Active".
  - _Requested:_ Fix the scheduler so a failed token refresh updates status/lastError (user was shown Active despite being disconnected), and add a notification to the affected user that their connection dropped — for both Google and Microsoft.
  - _Done:_ Extracted the shared status-classification + disconnect-notification logic into `services/sync-status.js`, used by both the webhook handler and the renewal cron. The scheduler's catch now classifies the error, persists `<provider>_disconnected` + lastError (transient errors leave status untouched), and notifies the owner and the affected user. Owner alerts are sent through the OWNER's own monday token (resolved from their config in the instance) so they survive the affected user's monday disconnect. Notifications target the Custom Object instance id (`target_id` = objectId), so clicking deep-links to `/custom_objects/<objectId>` (the admin app) instead of the synced board. Fixed the UI so disconnected/error statuses surface the red pill even on the connection owner's own row (the connection booleans only checked token existence, not validity). Updated CLAUDE.md (cron is `0 */12 * * *`, not `0 8 * * *`; storage schema; module map). Deployed to live app 11119011. **Discovered during testing:** monday `create_notification` was failing `UNAUTHORIZED_FIELD_OR_TYPE` because every stored monday token predates the `notifications:write` scope (added 2026-05-20; all tokens granted 6–10 May) — the notification feature had never actually worked. Confirmed re-auth fixes it: after re-authorizing monday, a manual cron trigger produced a successful `user_notified` and the deep-link works. Owner notifications still fail until the owner (Roni) re-auths. Branch not yet merged; live cron verification scheduled for 2026-06-04 00:00 UTC (first run past the 24h notification cooldown).

## 2026-05

### ♻️  Refactor

- **2026-05-28** — העשרת לוגים של שגיאות sync — code/status/body/stack ב-catch של webhook-config + try/catch ייעודי סביב provider.listChanges `2cb263c`
  - _Why:_ באג שאי-אפשר היה לאבחן ב-Axiom (cfg=0ff12f78, 'Provided input is invalid') כי הלוג חסר code/status/body/פונקציה זורקת
  - _Requested:_ 1. להעשיר את ה-catch ב-webhook-config.js עם err.code, err.status, err.body (אם קיים), ו-err.stack.split('\n')[1] כדי לקבל את הפונקציה הזורקת. 2. לעטוף את provider.listChanges ב-try/catch ייעודי שירשום את ה-stage מדויק (provider_list_changes) ואת ה-body של Graph אם זה 400.
  - _Done:_ Investigated a single Axiom error (cfg=0ff12f78, "Provided input is invalid", provider=microsoft) and found the outer catch in webhook-config.js logs only err.message — no code, status, body, or throwing frame, making the error undiagnosable. Added errCode, errStatus, errBody (capped at 500 chars), and throwAt (first stack frame) to the catch, and switched stage to honor err.stage when set. In sync-engine.js, wrapped both provider.listChanges calls in a listChangesTagged helper that tags errors with stage='provider_list_changes' and emits a dedicated log with the Graph body on 400. Built client, committed 2cb263c, deployed to monday code (v14818258, successful). Follow-up: verify in production that the new fields actually land in Axiom on the next real error — none has fired since deploy.
